import { environment } from '../../environments/environment';

export class ProviderService {

  private urlBase: string;
  private API: string;

  constructor(api: string) {
    this.urlBase = `${environment.url}`;
    this.API = api;
  }

  get url(): string {
    return `${this.urlBase}/${this.API}`;
  }

  urlOption(api: string): string {
    return `${this.urlBase}/${api}`;
  }
}
