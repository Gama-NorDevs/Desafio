export class User {
   constructor(
           public Name: string,
           public Email: string,
           public Password: string,
           public Profile: string,
           public Amount: number,
           public Sex: string,
    ){}
}
